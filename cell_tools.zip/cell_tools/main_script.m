%This script calls iteratively the analysis for single tif files and save the results in a csv file

%%%%%%%%%%%%%%%%%%%%%%%%%% SETTING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if method == 0 use global Otsu, otherwise 1 use adaptive threshold of Bradley and Roth.
method = 1;
% If you want to use the active contours segmentation to remove artefacts at the border of the pictures (as signal in the meningis)
% '1' means  use active contours, '0' don't. Consider that depending on the size of the volume this can seriously slow down the analysis
use_snake = 0;
load_partially = 1; % 0 to load one volume intererly, 1 to load parts

High_res = 0;  % Use params for  high resolution '1', other res '0'

if (High_res)
    open_size = 5;
    max_area = 15000;
else
    open_size = 1;
    max_area = 15000;
end 


%%%%%%%%%%%%%%%%%%%%%%%%%% LOADING DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If all files in one folder use the list
files = dir(fullfile('Q:\Data\Francesca Catto_PhD student\Roche 2020\BS-GANTE STITCHED 2\R_STITCH_BS-GANTENERUMAB_957961_5_APPPS1_CLDN5\filter_565\rot_0\RES(3385x1817x1237)\000000\000000_0-1560\', '*.tif'));
filenames = arrayfun(@(x) x.name, files, 'UniformOutput', false);
filenames = filenames';
filepaths = arrayfun(@(x) x.folder, files, 'UniformOutput', false);
filepaths = filepaths';
names = fullfile(filepaths, filenames);

% Go to this dir to save data (and where the code is)
%cd('C:/Users/Administrator/Documents/cell_tools');


%%%%%%%%%%%%%%%%%%%%%%%%%% MAIN CALL %%%%%%%%%%%%%%%%%

res = zeros( length(names),1);
vol_plaque = zeros( length(names),1);
% Split the big volume in n pieces of specific length
tot_block = 3;

for kk = 1 : length(names)
    disp(names(kk))
    
    if (load_partially)
        for zz = 1 : tot_block
            [res_t, vol_t] = extract_feat_par( names{kk}, method, use_snake,zz,tot_block,open_size, max_area);
            temp_res(zz) = res_t;
            temp_vol(zz) = vol_t;
        end
        res(kk) = sum(temp_res);
        vol_plaque(kk) = sum(temp_vol);
    else
        [res(kk),vol_plaque(kk)] = extract_feat_big( names{kk} , method, use_snake);
    end
    
    filename = 'dati_BS_GANTE_intermediate_results.csv';
    T = table( names',res,vol_plaque);
    T.Properties.VariableNames={'Filename', 'CellCount','Volume'};
    writetable(T,filename,'Delimiter',',');
end

%Initalize all labels as Placebo
labels = repmat('Placebo',length(names),1);
for uu = 1 : length(names)
         k = strfind(names{uu},'high');
         if (~isempty(k))
            labels(uu) = HD;
         end
         k = strfind(names{uu},'low');
         if (~isempty(k))
            labels(uu) = LD;
         end    
end

save %This will save variables into a .mat file
%split results
data_placebo = [];
data_hd = [];
data_ld = [];
data_placebo_vol = [];
data_hd_vol = [];
data_ld_vol = [];
for uu = 1 : length(names)
         k = strfind(names{uu},'high');
         if (~isempty(k))
             data_hd(end+1) = res(uu);
             data_hd_vol(end+1) = vol(uu);
         end
         k = strfind(names{uu},'low');
         if (~isempty(k))
            data_ld(end+1) = res(uu);
            data_ld_vol(end+1) = vol(uu);
         end    
         k = strfind(names{uu},'Placebo');
         if (~isempty(k))
            data_placebo(end+1)  = res(uu);
            data_placebo_vol(end+1)  = vol(uu);
         end    
end
hold on
boxplot(res,labels)
scatter(ones(size(data_hd))  ,data_hd,'r','filled')
scatter(ones(size(data_placebo))*3,data_placebo,'r','filled')
scatter(ones(size(data_ld))*2,data_ld,'r','filled')
hold off
hold on
figure; boxplot(vol_plaque,res)
scatter(ones(size(data_hd))  ,data_hd,'r','filled')
scatter(ones(size(data_placebo_vol))*3,data_placebo_vol,'r','filled')
scatter(ones(size(data_ld_vol))*2,data_ld_vol,'r','filled')
hold off

% This will export everything into a csv file
filename = 'dati_BS_GANTE_intermediate_results.csv';
T = table( names',res,vol_plaque);
T.Properties.VariableNames={'Filename', 'CellCount','Volume'};
writetable(T,filename,'Delimiter',',');